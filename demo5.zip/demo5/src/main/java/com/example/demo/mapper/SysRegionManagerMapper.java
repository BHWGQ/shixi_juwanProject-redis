package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.SysRegionManagerEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysRegionManagerMapper extends BaseMapper<SysRegionManagerEntity> {
}
